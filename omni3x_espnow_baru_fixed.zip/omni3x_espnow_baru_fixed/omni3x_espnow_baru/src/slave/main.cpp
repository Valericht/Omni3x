// Omni-3X SLAVE (ESP8266, ESP-NOW). Satu firmware untuk 3 board, dikenali dari MAC.
// Perbaikan dari versi lama: paket cocok dengan master, ramp, batas RPM, simpan PID ke flash,
// Auto Tuning relay, telemetri balik (broadcast, diberi jeda per ID agar tidak tabrakan).
#include <Arduino.h>
#include <cstddef>
#include <cmath>
#include <ESP8266WiFi.h>
#include <EEPROM.h>
extern "C" {
  #include <user_interface.h>
}
#include <espnow.h>
#include "omni_now.h"

#ifndef SLAVE_ID
#error "Gunakan env slave1, slave2, atau slave3 (ID roda diberikan lewat build flag, tanpa MAC)"
#endif
static_assert(SLAVE_ID >= 1 && SLAVE_ID <= 3, "SLAVE_ID harus 1..3");

// Parameter per roda (index = ID - 1). Ubah motorSign/encSign di sini jika arah terbalik.
struct WheelCfg {
  float  cpr;
  int8_t motorSign;
  int8_t encSign;
  float  kp, ki, kd;
};
const WheelCfg WHEELS[3] = {
  { 3860.0, 1, 1, 0.717, 23.896, 0.0048 },   // roda 1 (encoder A = 14, B = 12)
  { 3860.0, 1, 1, 0.717, 23.896, 0.0048 },   // roda 2 (encoder A = 14, B = 12)
  { 3860.0, -1, -1, 0.724, 24.148, 0.0054 },   // roda 3 Encoder terbalik A -> GPIO12 (D6), B -> GPIO14 (D5)
};

// ---- Pin (sama dengan proyek kamu) ----
const uint8_t PIN_ENC_A = 14;
const uint8_t PIN_ENC_B = 12;
// Driver TANPA pin enable: PWM langsung di dua pin arah (IN1 = maju, IN2 = mundur).
// Contoh: BTS7960 (IN1=RPWM, IN2=LPWM, R_EN/L_EN ke VCC), L298N dengan jumper ENA/ENB terpasang.
// Set 0 hanya jika driver punya pin enable/PWM terpisah (PIN_PWM).
#define DUAL_PWM 1
const uint8_t PIN_PWM   = 13;    // hanya dipakai jika DUAL_PWM 0
const uint8_t PIN_IN1   = 5;    // maju  (PWM)
const uint8_t PIN_IN2   = 4;   // mundur (PWM)

const uint32_t SAMPLE_MS  = 20;
const uint32_t TIMEOUT_MS = 500;
const float    ACCEL_RPM_S = 300.0f;   // batas percepatan target
const float    LIMIT_DEFAULT = 100.0f;
#define SERIAL_DEBUG 1

uint8_t WHEEL_ID = 0;
float   CPR = 3860.0f;
int8_t  MOTOR_SIGN = 1, ENC_SIGN = 1;
float   Kp = 0.6f, Ki = 0.8f, Kd = 0.0f, limitRpm = LIMIT_DEFAULT;

uint8_t bcast[] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};

// ---- flash ----
struct Cfg { uint32_t magic; float kp, ki, kd, limit; uint16_t crc; } cfg;
#define CFG_MAGIC 0x4F4E5731UL
uint16_t crc16(const uint8_t *d, size_t n) {
  uint16_t c = 0xFFFF;
  while (n--) { c ^= *d++; for (int i = 0; i < 8; i++) c = (c & 1) ? (c >> 1) ^ 0xA001 : (c >> 1); }
  return c;
}
void loadCfg() {
  EEPROM.get(0, cfg);
  if (cfg.magic == CFG_MAGIC && cfg.crc == crc16((uint8_t *)&cfg, offsetof(Cfg, crc))) {
    bool ok = std::isfinite(cfg.kp) && std::isfinite(cfg.ki) && std::isfinite(cfg.kd) && std::isfinite(cfg.limit) &&
              cfg.kp >= 0 && cfg.ki >= 0 && cfg.kd >= 0 && cfg.limit >= 5.0f && cfg.limit <= 1000.0f;
    if (!ok) { Serial.println("Konfigurasi flash tidak valid, pakai default"); return; }
    Kp = cfg.kp; Ki = cfg.ki; Kd = cfg.kd; limitRpm = cfg.limit;
    Serial.println("Konfigurasi dimuat dari flash");
  }
}
void saveCfg() {
  cfg.magic = CFG_MAGIC; cfg.kp = Kp; cfg.ki = Ki; cfg.kd = Kd; cfg.limit = limitRpm;
  cfg.crc = crc16((uint8_t *)&cfg, offsetof(Cfg, crc));
  EEPROM.put(0, cfg);
  EEPROM.commit();
}

// ---- encoder (x1, RISING A) ----
volatile long pos = 0;
void IRAM_ATTR readEncoder() {
  if (digitalRead(PIN_ENC_B)) pos++; else pos--;
}

// ---- state ----
volatile float    rxRpm = 0;
volatile uint32_t lastRx = 0;
volatile bool     replyPending = false;
volatile uint32_t replyDue = 0;
bool failsafe = true;
volatile uint32_t rxDriveCnt = 0, txOkCnt = 0, txFailCnt = 0;
uint32_t lastTelTx = 0, lastChk = 0, lastLink = 0, chFixCnt = 0;

// perintah dari callback, dieksekusi di loop()
struct Pending { volatile bool has; uint8_t type; float a, b, c; uint8_t rule; } pend;
uint8_t lastSeq = 0;

long  lastPos = 0;
float integral = 0, prevMeas = 0, rpmFilt = 0, rampRpm = 0, targetRpm = 0;
int   pwmOut = 0;
uint32_t lastT = 0, lastDbg = 0;

// ---- Auto Tuning relay ----
enum { AT_IDLE, AT_SPIN, AT_RELAY, AT_DONE, AT_FAIL };
uint8_t atState = AT_IDLE, atRule = 2;
float atSp, atBias, atD, atPwm, atMax, atMin, atPer[6], atAmp[6];
bool atHigh;
uint32_t atT0, atLastHigh;
uint8_t atCycles;

bool atRunning() { return atState == AT_SPIN || atState == AT_RELAY; }

void motorDrive(int pwm) {
  pwm = constrain(pwm * MOTOR_SIGN, -255, 255);
  pwmOut = pwm;
#if DUAL_PWM
  // matikan pin arah lawan dulu, baru nyalakan pin arah tujuan
  if (pwm > 0)      { analogWrite(PIN_IN2, 0);   analogWrite(PIN_IN1, pwm); }
  else if (pwm < 0) { analogWrite(PIN_IN1, 0);   analogWrite(PIN_IN2, -pwm); }
  else              { analogWrite(PIN_IN1, 0);   analogWrite(PIN_IN2, 0); }
#else
  if (pwm > 0)      { digitalWrite(PIN_IN1, HIGH); digitalWrite(PIN_IN2, LOW);  analogWrite(PIN_PWM, pwm); }
  else if (pwm < 0) { digitalWrite(PIN_IN1, LOW);  digitalWrite(PIN_IN2, HIGH); analogWrite(PIN_PWM, -pwm); }
  else              { digitalWrite(PIN_IN1, LOW);  digitalWrite(PIN_IN2, LOW);  analogWrite(PIN_PWM, 0); }
#endif
}

void stopMotion() {
  targetRpm = 0; rampRpm = 0; integral = 0;
  if (atRunning()) atState = AT_FAIL;
  motorDrive(0);
}

void identifyBoard() {
  const WheelCfg &w = WHEELS[SLAVE_ID - 1];
  WHEEL_ID = SLAVE_ID; CPR = w.cpr;
  MOTOR_SIGN = w.motorSign; ENC_SIGN = w.encSign;
  Kp = w.kp; Ki = w.ki; Kd = w.kd;
  Serial.printf("SLAVE %d  MAC: %s\n", WHEEL_ID, WiFi.macAddress().c_str());
  Serial.printf("Roda %d, CPR %.0f, motorSign %d, encSign %d\n", WHEEL_ID, CPR, MOTOR_SIGN, ENC_SIGN);
}

// ---- ESP-NOW terima (konteks Wi-Fi: jangan kerja berat di sini) ----
void onRecv(uint8_t *mac, uint8_t *data, uint8_t len) {
  if (WHEEL_ID < 1 || WHEEL_ID > 3 || len < sizeof(Hdr)) return;
  Hdr h; memcpy(&h, data, sizeof(h));
  if (h.magic != MAGIC_CMD) return;

  if (h.type == T_DRIVE) {
    if (len != sizeof(PktDrive)) return;
    PktDrive p; memcpy(&p, data, sizeof(p));
    rxRpm = p.rpm[WHEEL_ID - 1];
    lastRx = millis();
    if (lastRx == 0) lastRx = 1;
    rxDriveCnt++;
    replyDue = lastRx + WHEEL_ID * 6;         // jeda per ID (6/12/18 ms) agar balasan tidak tabrakan
    replyPending = true;
    return;
  }
  if (h.target != 0 && h.target != WHEEL_ID) return;
  if (h.seq == lastSeq || pend.has) return;     // duplikat (master mengulang tiap perintah)
  lastSeq = h.seq;
  pend.type = h.type; pend.a = pend.b = pend.c = 0; pend.rule = 0;
  if (h.type == T_PID && len == sizeof(PktPid))          { PktPid p;   memcpy(&p, data, sizeof(p)); pend.a = p.kp; pend.b = p.ki; pend.c = p.kd; }
  else if (h.type == T_LIMIT && len == sizeof(PktLimit)) { PktLimit p; memcpy(&p, data, sizeof(p)); pend.a = p.rpm; }
  else if (h.type == T_AT && len == sizeof(PktAt))       { PktAt p;    memcpy(&p, data, sizeof(p)); pend.a = p.sp; pend.rule = p.rule; }
  pend.has = true;
}

void execPending() {
  if (!pend.has) return;
  switch (pend.type) {
    case T_PID:
      if (pend.a >= 0 && pend.b >= 0 && pend.c >= 0) { Kp = pend.a; Ki = pend.b; Kd = pend.c; integral = 0; }
      break;
    case T_LIMIT: limitRpm = constrain(pend.a, 5.0f, 1000.0f); break;
    case T_SAVE:  saveCfg(); break;
    case T_STOP:  stopMotion(); atState = AT_IDLE; break;
    case T_ZERO:  noInterrupts(); pos = 0; interrupts(); lastPos = 0; integral = 0; if (!atRunning()) atState = AT_IDLE; break;
    case T_AT:
      if (!atRunning()) {
        atSp = constrain(pend.a, 5.0f, limitRpm); atRule = pend.rule > 2 ? 2 : pend.rule;
        atPwm = 0; atState = AT_SPIN; atT0 = millis(); integral = 0; targetRpm = rampRpm = 0;
      }
      break;
  }
  pend.has = false;
}

// Satu langkah Auto Tuning relay. Kembalikan PWM (0..255).
int atStep(float rpm) {
  if (millis() - atT0 > 40000) { atState = AT_FAIL; return 0; }
  if (atState == AT_SPIN) {
    atPwm += 1.0f;                       // ~50 PWM/detik
    if (rpm >= atSp) {
      atBias = atPwm;
      atD = min(atBias * 0.4f, 255.0f - atBias);
      if (atD < 8.0f) { atState = AT_FAIL; return 0; }
      atD = max(atD, min(15.0f, 255.0f - atBias));
      atHigh = true; atMax = -1e9f; atMin = 1e9f; atLastHigh = 0; atCycles = 0;
      atState = AT_RELAY;
    } else if (atPwm >= 255.0f) { atState = AT_FAIL; return 0; }
    return (int)atPwm;
  }
  float hyst = max(2.5f, 0.06f * atSp);
  atMax = max(atMax, rpm); atMin = min(atMin, rpm);
  if (atHigh && rpm > atSp + hyst) {
    atHigh = false;
  } else if (!atHigh && rpm < atSp - hyst) {
    atHigh = true;
    uint32_t t = millis();
    if (atLastHigh) {
      if (atCycles < 6) { atPer[atCycles] = (t - atLastHigh) / 1000.0f; atAmp[atCycles] = (atMax - atMin) / 2.0f; }
      atCycles++;
    }
    atLastHigh = t; atMax = -1e9f; atMin = 1e9f;
    if (atCycles >= 6) {
      float Tu = 0, a = 0;
      for (int i = 2; i < 6; i++) { Tu += atPer[i]; a += atAmp[i]; }
      Tu /= 4; a /= 4;
      if (Tu <= 0.05f || a <= 0.5f) { atState = AT_FAIL; return 0; }
      float Ku = 4.0f * atD / (PI * a);
      float kp, ti, td;
      if (atRule == 0)      { kp = 0.60f * Ku; ti = 0.50f * Tu; td = 0.125f * Tu; }   // Ziegler-Nichols klasik
      else if (atRule == 1) { kp = 0.33f * Ku; ti = 0.50f * Tu; td = 0.33f * Tu; }    // sedikit overshoot
      else                  { kp = 0.20f * Ku; ti = 0.50f * Tu; td = 0.33f * Tu; }    // tanpa overshoot
      Kp = kp; Ki = kp / ti; Kd = kp * td;
      atState = AT_DONE;
      return 0;
    }
  }
  return (int)(atBias + (atHigh ? atD : -atD));
}

uint8_t flagsNow() {
  uint8_t f = 0;
  if (failsafe) f |= FLG_FAILSAFE;
  if (atRunning()) f |= FLG_AT_RUN;
  if (atState == AT_DONE) f |= FLG_AT_DONE;
  return f;
}
uint8_t atByte() {
  if (atRunning()) return 1;
  if (atState == AT_DONE) return 2;
  if (atState == AT_FAIL) return 3;
  return 0;
}

void sendTelemetry() {
  PktTel t;
  t.magic = MAGIC_TEL; t.id = WHEEL_ID; t.flags = flagsNow(); t.at = atByte();
  t.rpm = rpmFilt; t.target = targetRpm; t.pwm = pwmOut;
  t.kp = Kp; t.ki = Ki; t.kd = Kd; t.limit = limitRpm;
  esp_now_send(bcast, (uint8_t *)&t, sizeof(t));
}

void control(float dt) {
  noInterrupts(); long p = pos; interrupts();
  long delta = (p - lastPos) * ENC_SIGN;
  lastPos = p;
  float rpm = (delta / CPR) * (60.0f / dt);
  rpmFilt = 0.7f * rpmFilt + 0.3f * rpm;

  uint32_t now = millis();
  bool fs = (lastRx == 0) || (now - lastRx > TIMEOUT_MS);
  if (fs && !failsafe && atRunning()) atState = AT_FAIL;
  failsafe = fs;

  static bool wasAt = false;
  if (atRunning()) { wasAt = true; motorDrive(atStep(rpmFilt)); return; }
  if (wasAt) { wasAt = false; integral = 0; prevMeas = rpmFilt; rampRpm = 0; }   // keluar dari Auto Tuning: bersihkan state PID

  targetRpm = fs ? 0 : constrain((float)rxRpm, -limitRpm, limitRpm);
  float step = ACCEL_RPM_S * dt;
  if (rampRpm < targetRpm) rampRpm = min(rampRpm + step, targetRpm);
  else if (rampRpm > targetRpm) rampRpm = max(rampRpm - step, targetRpm);

  if (fabsf(rampRpm) < 0.5f && fabsf(targetRpm) < 0.5f) { integral = 0; prevMeas = rpmFilt; motorDrive(0); return; }

  float err = rampRpm - rpmFilt;
  integral += err * dt;
  float iLimit = (Ki > 0) ? (255.0f / Ki) : 0;
  integral = constrain(integral, -iLimit, iLimit);
  float dMeas = (rpmFilt - prevMeas) / dt;
  prevMeas = rpmFilt;
  float out = Kp * err + Ki * integral - Kd * dMeas;
  motorDrive((int)constrain(out, -255.0f, 255.0f));
}

void onSent(uint8_t *mac, uint8_t status) {
  if (status == 0) txOkCnt++; else txFailCnt++;
}

void setup() {
  Serial.begin(115200);
  pinMode(PIN_ENC_A, INPUT_PULLUP);
  pinMode(PIN_ENC_B, INPUT_PULLUP);
  attachInterrupt(digitalPinToInterrupt(PIN_ENC_A), readEncoder, RISING);
  pinMode(PIN_IN1, OUTPUT); pinMode(PIN_IN2, OUTPUT);
#if !DUAL_PWM
  pinMode(PIN_PWM, OUTPUT);
#endif
  analogWriteRange(255);
  analogWriteFreq(1000);
  motorDrive(0);

  EEPROM.begin(64);
  WiFi.persistent(false);          // jangan tulis/baca konfigurasi Wi-Fi lama dari flash
  WiFi.setAutoConnect(false);      // jangan coba sambung ke AP lama (membuat kanal berpindah)
  WiFi.setAutoReconnect(false);
  WiFi.mode(WIFI_STA);
  WiFi.disconnect();
  identifyBoard();
  loadCfg();
  wifi_set_channel(WIFI_CH);

  if (esp_now_init() != 0) { Serial.println("ESP-NOW gagal"); return; }
  esp_now_set_self_role(ESP_NOW_ROLE_COMBO);
  esp_now_add_peer(bcast, ESP_NOW_ROLE_COMBO, WIFI_CH, NULL, 0);
  esp_now_register_recv_cb(onRecv);
  esp_now_register_send_cb(onSent);
  pend.has = false;
  lastT = millis();
}

void loop() {
  execPending();

  uint32_t now = millis();
  if (now - lastT >= SAMPLE_MS) {
    float dt = (now - lastT) / 1000.0f;
    lastT = now;
    control(dt);
  }
  if (replyPending && (int32_t)(millis() - replyDue) >= 0) {
    replyPending = false;
    lastTelTx = millis();
    sendTelemetry();
  }
  // heartbeat tiap 500 ms walau tidak ada paket master: GUI "online + failsafe" = slave bisa kirim tapi tidak menerima
  if (millis() - lastTelTx > 500) {
    lastTelTx = millis();
    sendTelemetry();
  }
  // jaga kanal tetap WIFI_CH
  if (millis() - lastChk > 2000) {
    lastChk = millis();
    if (wifi_get_channel() != WIFI_CH) { wifi_set_channel(WIFI_CH); chFixCnt++; }
  }
  if (millis() - lastLink > 2000) {
    lastLink = millis();
    Serial.printf("[LINK] w%d ch:%d rxDrive:%u txOk:%u txFail:%u chFix:%u usiaDrive:%ums\n",
                  WHEEL_ID, wifi_get_channel(), (unsigned)rxDriveCnt, (unsigned)txOkCnt, (unsigned)txFailCnt,
                  (unsigned)chFixCnt, lastRx ? (unsigned)(millis() - lastRx) : 0u);
  }
#if SERIAL_DEBUG
  if (now - lastDbg > 250) {
    lastDbg = now;
    Serial.printf("w%d t:%.1f rpm:%.1f pwm:%d Kp:%.3f Ki:%.2f Kd:%.4f at:%d%s\n",
                  WHEEL_ID, targetRpm, rpmFilt, pwmOut, Kp, Ki, Kd, atByte(), failsafe ? " FS" : "");
  }
#endif
  yield();
}
