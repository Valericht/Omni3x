// Omni-3X MASTER (ESP8266). ESP-NOW ke 3 slave + Access Point + dashboard web (GUI) + CLI Serial.
// Library: ESPAsyncWebServer + ESPAsyncTCP. Upload data/ ke LittleFS (pio run -e master -t uploadfs).
#include <Arduino.h>
#include <ESP8266WiFi.h>
#include <ESPAsyncTCP.h>
#include <ESPAsyncWebServer.h>
#include <LittleFS.h>
extern "C" {
  #include <user_interface.h>
}
#include <espnow.h>
#include "omni_now.h"

#define AP_SSID       "Omni3X"
#define AP_PASS       "omni1234"     // minimal 8 karakter
#define AP_MAX_CLIENT 4
#define SEND_MS       50             // 20 Hz
#define CMD_REPEAT    6              // tiap perintah dikirim 6x (300 ms) lalu dianggap sampai
#define WEB_FAILSAFE_MS 300
#define SLAVE_ONLINE_MS 600
#define TELEMETRY_MS  100
#define USE_BATTERY   0              // 1: baca baterai dari A0 (pembagi tegangan)
#define BAT_V_PER_COUNT 0.0145f
#define BAT_V_EMPTY   9.0f
#define BAT_V_FULL    12.6f

const float L = 0.15f;               // jari-jari robot (m)
const float D = 0.058f;              // diameter roda (m)
const float THETA_DEG[3] = {90, 210, 330};

AsyncWebServer server(80);
AsyncWebSocket ws("/ws");
uint8_t bcast[] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};

// ---- gerak ----
float vx = 0, vy = 0, wz = 0;                 // m/s, m/s, rad/s
float manualRpm[3] = {0, 0, 0};
bool  manualMode = false;
float outRpm[3] = {0, 0, 0};
float limitRpm = 100;
int   speedPct = 100;
bool  webDriving = false;
uint32_t lastWebMs = 0;

// ---- telemetri slave ----
PktTel tel[3];
uint32_t telRx[3] = {0, 0, 0};
uint8_t  prevAt[3] = {0, 0, 0};
uint32_t telCnt[3] = {0, 0, 0};

// ---- antrean perintah (diulang CMD_REPEAT kali, slave membuang duplikat lewat seq) ----
struct Cmd { uint8_t type, target, seq, rule; float a, b, c; };
Cmd q[8];
uint8_t qn = 0, qRep = 0, seqCounter = 0;

bool enqueue(uint8_t type, uint8_t target, float a = 0, float b = 0, float c = 0, uint8_t rule = 0, bool front = false) {
  if (qn >= 8) { if (!front) return false; qn = 7; }   // STOP/prioritas membuang perintah paling belakang
  seqCounter++; if (seqCounter == 0) seqCounter = 1;
  Cmd cm = {type, target, seqCounter, rule, a, b, c};
  if (front) { for (int i = qn; i > 0; i--) q[i] = q[i - 1]; q[0] = cm; qRep = 0; }
  else q[qn] = cm;
  qn++;
  return true;
}

void sendCmd(const Cmd &c) {
  Hdr h = {MAGIC_CMD, c.type, c.seq, c.target};
  switch (c.type) {
    case T_PID:   { PktPid p = {h, c.a, c.b, c.c}; esp_now_send(bcast, (uint8_t *)&p, sizeof(p)); } break;
    case T_LIMIT: { PktLimit p = {h, c.a}; esp_now_send(bcast, (uint8_t *)&p, sizeof(p)); } break;
    case T_AT:    { PktAt p = {h, c.a, c.rule}; esp_now_send(bcast, (uint8_t *)&p, sizeof(p)); } break;
    default:      { PktCmd p = {h}; esp_now_send(bcast, (uint8_t *)&p, sizeof(p)); } break;
  }
}

// ---- kinematika (diperbaiki: normalisasi pakai nilai absolut dan skala proporsional) ----
void compute() {
  if (manualMode) {
    for (int i = 0; i < 3; i++) outRpm[i] = manualRpm[i];
  } else {
    for (int i = 0; i < 3; i++) {
      float th = THETA_DEG[i] * DEG_TO_RAD;
      float v = -sinf(th) * vx + cosf(th) * vy + L * wz;
      outRpm[i] = v / (PI * D) * 60.0f;
    }
  }
  float m = 0;
  for (int i = 0; i < 3; i++) m = max(m, fabsf(outRpm[i]));
  float lim = limitRpm * speedPct / 100.0f;
  if (m > lim && m > 0) for (int i = 0; i < 3; i++) outRpm[i] *= lim / m;
}

void webStop() {                 // hentikan kendali dari GUI (joystick atau tes roda)
  vx = vy = wz = 0;
  manualRpm[0] = manualRpm[1] = manualRpm[2] = 0;
  manualMode = false;
  webDriving = false;
}

void stopAll() {
  vx = vy = wz = 0;
  manualRpm[0] = manualRpm[1] = manualRpm[2] = 0;
  manualMode = false;
  webDriving = false;
  enqueue(T_STOP, 0, 0, 0, 0, 0, true);
}

// ---- ESP-NOW terima telemetri ----
void onRecv(uint8_t *mac, uint8_t *data, uint8_t len) {
  if (len != sizeof(PktTel) || data[0] != MAGIC_TEL) return;
  PktTel t; memcpy(&t, data, sizeof(t));
  if (t.id < 1 || t.id > 3) return;
  tel[t.id - 1] = t;
  telRx[t.id - 1] = millis();
  telCnt[t.id - 1]++;
}

// ---- CLI Serial ----
void handleSerial() {
  if (!Serial.available()) return;
  String s = Serial.readStringUntil('\n');
  s.trim();
  if (s.length() == 0) return;
  const char *p = s.c_str();
  int id; float a, b, c;

  if (s == "s" || s == "S") { stopAll(); return; }
  if (s == "zero") { enqueue(T_ZERO, 0); return; }
  if (!strncmp(p, "pid ", 4)) { if (sscanf(p + 4, "%d %f %f %f", &id, &a, &b, &c) == 4) enqueue(T_PID, id, a, b, c); return; }
  if (!strncmp(p, "at ", 3))  { int rule = 2; a = 30; if (sscanf(p + 3, "%d %f %d", &id, &a, &rule) >= 1) enqueue(T_AT, id, a, 0, 0, rule); return; }
  if (!strncmp(p, "save ", 5)) { if (sscanf(p + 5, "%d", &id) == 1) enqueue(T_SAVE, id); return; }
  if (!strncmp(p, "lim ", 4))  { if (sscanf(p + 4, "%f", &a) == 1) { limitRpm = constrain(a, 5.0f, 1000.0f); enqueue(T_LIMIT, 0, limitRpm); } return; }

  int eq = s.indexOf('=');
  if (eq > 0) {
    int w = s.substring(0, eq).toInt();
    if (w >= 1 && w <= 3) { manualMode = true; webDriving = false; manualRpm[w - 1] = s.substring(eq + 1).toFloat(); }
    return;
  }
  char ch = s[0];
  float v = s.substring(1).toFloat();
  if (ch == 'x' || ch == 'y' || ch == 'w') {
    manualMode = false; webDriving = false;
    if (ch == 'x') vx = v;
    if (ch == 'y') vy = v;
    if (ch == 'w') wz = v;
  }
}

// ---- WebSocket (GUI) ----
// Pesan: M,vx,vy,w | S | PID,id,kp,ki,kd | LIM,rpm | SPD,pct | SAVE,id | AT,id,sp,rule | CAL | P,ts
void handleMsg(AsyncWebSocketClient *cl, char *m) {
  float a, b, c; int id, rule;
  if (m[0] == 'M' && m[1] == ',') {
    if (sscanf(m + 2, "%f,%f,%f", &a, &b, &c) == 3) {
      a = constrain(a, -1.0f, 1.0f); b = constrain(b, -1.0f, 1.0f); c = constrain(c, -1.0f, 1.0f);
      float vmax = limitRpm / 60.0f * PI * D;          // m/s saat roda berputar di batas RPM
      vx = a * vmax; vy = b * vmax; wz = c * vmax / L;
      manualMode = false; webDriving = true; lastWebMs = millis();
    }
  } else if (!strcmp(m, "S")) {
    stopAll();
  } else if (!strcmp(m, "CAL")) {
    enqueue(T_ZERO, 0);
  } else if (!strncmp(m, "PID,", 4)) {
    if (sscanf(m + 4, "%d,%f,%f,%f", &id, &a, &b, &c) == 4 && id >= 0 && id <= 3) enqueue(T_PID, id, a, b, c);
  } else if (!strncmp(m, "LIM,", 4)) {
    if (sscanf(m + 4, "%f", &a) == 1) { limitRpm = constrain(a, 5.0f, 1000.0f); enqueue(T_LIMIT, 0, limitRpm); }
  } else if (!strncmp(m, "SPD,", 4)) {
    if (sscanf(m + 4, "%d", &id) == 1) speedPct = constrain(id, 5, 100);
  } else if (!strncmp(m, "SAVE,", 5)) {
    if (sscanf(m + 5, "%d", &id) == 1 && id >= 0 && id <= 3) enqueue(T_SAVE, id);
  } else if (!strncmp(m, "AT,", 3)) {
    rule = 2; a = 30;
    if (sscanf(m + 3, "%d,%f,%d", &id, &a, &rule) >= 1 && id >= 0 && id <= 3) {
      vx = vy = wz = 0; webDriving = false; manualMode = false;
      enqueue(T_AT, id, a, 0, 0, rule);
    }
  } else if (m[0] == 'W' && m[1] == ',') {          // tes satu roda: W,id,rpm (id 0 = semua roda)
    if (sscanf(m + 2, "%d,%f", &id, &a) == 2 && id >= 0 && id <= 3) {
      a = constrain(a, -limitRpm, limitRpm);
      for (int i = 0; i < 3; i++) manualRpm[i] = (id == 0 || id == i + 1) ? a : 0;
      manualMode = true; webDriving = true; lastWebMs = millis();
    }
  } else if (m[0] == 'P' && m[1] == ',') {
    char r[32]; snprintf(r, sizeof(r), "P,%s", m + 2); cl->text(r);
  }
}

void onWs(AsyncWebSocket *s, AsyncWebSocketClient *cl, AwsEventType t, void *arg, uint8_t *data, size_t len) {
  if (t == WS_EVT_DATA) {
    AwsFrameInfo *info = (AwsFrameInfo *)arg;
    if (info->final && info->index == 0 && info->len == len && info->opcode == WS_TEXT && len < 80) {
      char m[84]; memcpy(m, data, len); m[len] = 0;
      handleMsg(cl, m);
    }
  } else if (t == WS_EVT_DISCONNECT) {
    if (ws.count() <= 1 && webDriving) webStop();
  }
}

void sendTelemetry() {
  if (ws.count() == 0 || !ws.availableForWriteAll()) return;
  float v = 0; int pct = 0;
#if USE_BATTERY
  v = analogRead(A0) * BAT_V_PER_COUNT;
  pct = constrain((int)((v - BAT_V_EMPTY) / (BAT_V_FULL - BAT_V_EMPTY) * 100.0f), 0, 100);
#endif
  static char b[700];
  int n = snprintf(b, sizeof(b), "{\"b\":%.2f,\"p\":%d,\"c\":%u,\"lim\":%d,\"spd\":%d,\"s\":[", v, pct, ws.count(), (int)limitRpm, speedPct);
  uint32_t now = millis();
  for (int i = 0; i < 3; i++) {
    bool on = telRx[i] && (now - telRx[i]) < SLAVE_ONLINE_MS;
    PktTel &t = tel[i];
    n += snprintf(b + n, sizeof(b) - n,
      "%s{\"o\":%d,\"r\":%d,\"t\":%d,\"w\":%d,\"f\":%d,\"tn\":%d,\"kp\":%.4f,\"ki\":%.3f,\"kd\":%.5f}",
      i ? "," : "", on, (int)t.rpm, (int)t.target, t.pwm, t.flags, t.at == 1,
      constrain(t.kp, -9999.0f, 9999.0f), constrain(t.ki, -9999.0f, 9999.0f), constrain(t.kd, -9999.0f, 9999.0f));
    if (n >= (int)sizeof(b) - 4) return;         // terpotong: lebih baik lewati satu frame daripada kirim JSON rusak
  }
  snprintf(b + n, sizeof(b) - n, "]}");
  ws.textAll(b);
}

void checkAutotuneDone() {
  for (int i = 0; i < 3; i++) {
    uint8_t at = (telRx[i] && millis() - telRx[i] < SLAVE_ONLINE_MS) ? tel[i].at : prevAt[i];
    if (prevAt[i] == 1 && at >= 2) {
      char b[96];
      snprintf(b, sizeof(b), "A,%d,%d,%.4f,%.3f,%.5f", i + 1, at, tel[i].kp, tel[i].ki, tel[i].kd);
      ws.textAll(b);
      Serial.println(b);
    }
    prevAt[i] = at;
  }
}

void setup() {
  Serial.begin(115200);
  Serial.setTimeout(10);
  if (!LittleFS.begin()) Serial.println("LittleFS gagal: jalankan pio run -e master -t uploadfs");

  WiFi.persistent(false);
  WiFi.setAutoConnect(false);
  WiFi.setAutoReconnect(false);
  WiFi.mode(WIFI_AP_STA);
  WiFi.disconnect();
  WiFi.softAP(AP_SSID, AP_PASS, WIFI_CH, false, AP_MAX_CLIENT);
  wifi_set_channel(WIFI_CH);

  if (esp_now_init() != 0) {
    Serial.println("ESP-NOW gagal");
  } else {
    esp_now_set_self_role(ESP_NOW_ROLE_COMBO);
    esp_now_add_peer(bcast, ESP_NOW_ROLE_COMBO, WIFI_CH, NULL, 0);
    esp_now_register_recv_cb(onRecv);
  }

  ws.onEvent(onWs);
  server.addHandler(&ws);
  server.serveStatic("/", LittleFS, "/").setDefaultFile("index.html");
  server.begin();

  Serial.println("Siap. GUI: sambung Wi-Fi Omni3X, buka http://192.168.4.1");
  Serial.println("CLI: x<m/s> y<m/s> w<rad/s> | 1=40 (RPM satu roda) | s | pid <id> kp ki kd | at <id> [rpm] [rule] | save <id> | lim <rpm> | zero");
}

void loop() {
  static uint32_t lastSend = 0, lastTel = 0;
  static bool cmdSent = true;
  uint32_t now = millis();

  handleSerial();

  if (webDriving && (now - lastWebMs) > WEB_FAILSAFE_MS) webStop();

  static uint32_t lastLink = 0;
  if (now - lastLink > 2000) {
    lastLink = now;
    Serial.printf("[LINK] ch:%d", wifi_get_channel());
    for (int i = 0; i < 3; i++)
      Serial.printf(" | s%d rx:%u usia:%ums", i + 1, (unsigned)telCnt[i], telRx[i] ? (unsigned)(now - telRx[i]) : 0u);
    Serial.println();
  }

  if (now - lastSend >= SEND_MS) {
    lastSend = now;
    compute();
    PktDrive p = {{MAGIC_CMD, T_DRIVE, 0, 0}, {outRpm[0], outRpm[1], outRpm[2]}};
    esp_now_send(bcast, (uint8_t *)&p, sizeof(p));
    cmdSent = false;
  }
  // perintah dikirim terpisah ~25 ms setelah paket DRIVE (ESP-NOW tidak boleh kirim berurutan rapat)
  if (!cmdSent && (now - lastSend) >= 25) {
    cmdSent = true;
    if (qn > 0) {
      sendCmd(q[0]);
      if (++qRep >= CMD_REPEAT) {
        for (int i = 1; i < qn; i++) q[i - 1] = q[i];
        qn--; qRep = 0;
      }
    }
  }

  checkAutotuneDone();
  if (now - lastTel >= TELEMETRY_MS) { lastTel = now; sendTelemetry(); ws.cleanupClients(); }
}
