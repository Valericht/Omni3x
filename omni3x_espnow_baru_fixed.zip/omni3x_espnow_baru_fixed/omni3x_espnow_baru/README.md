# Omni-3X ESP-NOW + GUI

Slave tetap ESP-NOW (tanpa router). Master = ESP-NOW + Access Point `Omni3X` + dashboard web + CLI Serial.

## Driver motor
Driver tanpa pin enable: PWM langsung di dua pin arah. `PIN_IN1` = GPIO5 (D1) = maju, `PIN_IN2` = GPIO4 (D2) = mundur
(BTS7960: IN1 = RPWM, IN2 = LPWM, R_EN dan L_EN ke VCC). Pin ada di `src/slave/main.cpp`.
Kalau roda terbalik: ubah `motorSign` dan `encSign` roda itu di tabel `WHEELS` (keduanya sekaligus, tanpa tukar pin encoder).
Driver dengan pin enable: set `DUAL_PWM 0`.

## Board offline? (diagnosis cepat)
Serial slave dan master mencetak `[LINK]` tiap 2 detik.
- Slave `rxDrive` naik = slave menerima master. Tidak naik = masalah kanal/jarak/AP master.
- Slave `txOk` naik tapi master `rx` roda itu tidak naik = master tidak menerima telemetri.
- GUI "online" + flag failsafe = slave bisa kirim tapi tidak menerima perintah master.
- Kalau upload sendiri offline tapi `erase_flash` + upload online: jalankan `pio run -e slave -t erase`, lalu upload ulang.

## Upload (ID roda dari env, tanpa MAC)
    pio run -e slave1 -t upload --upload-port /dev/ttyUSB1   # slave2, slave3 sama
    pio run -e master -t upload --upload-port /dev/ttyUSB0
    pio run -e master -t uploadfs --upload-port /dev/ttyUSB0     # GUI
Satu board = satu env slave. Board yang pernah memakai firmware lain: `pio run -e slave1 -t erase --upload-port ...` dulu.
Parameter per roda (CPR, motorSign, encSign, PID awal) ada di tabel `WHEELS`, bukan di MAC.

## Pakai GUI
Sambung HP/laptop ke Wi-Fi `Omni3X` (pass `omni1234`), buka http://192.168.4.1.
Joystick kiri = geser, kanan = putar. Keyboard W/A/S/D, Q/E. Tombol STOP, slider kecepatan, batas RPM.
PID Tuning Mode: pilih roda, isi Kp/Ki/Kd lalu Apply, atau Auto Tuning (isi RPM tuning + aturan), lalu Save to Flash.

## CLI Serial master (115200)
    x0.2  y0.1  w0.5      m/s, m/s, rad/s
    1=40                  roda 1 40 RPM (manual)
    s                     stop
    pid 1 0.7 23 0.005    set PID roda 1 (id 0 = semua)
    at 1 30 2             auto tuning roda 1, 30 RPM, aturan 2
    save 1 | lim 100 | zero

## Alat PC
    python3 tools/autotune_sim.py --sp 30 --rule 2     # uji logika Auto Tuning tanpa hardware
