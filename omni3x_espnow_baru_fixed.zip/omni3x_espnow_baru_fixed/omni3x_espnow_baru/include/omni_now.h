// Paket ESP-NOW Omni-3X (master <-> slave). Semua lewat broadcast, kanal 1.
// Master -> slave: magic 0xA5.  Slave -> master: magic 0xB5.
#pragma once
#include <Arduino.h>

#define MAGIC_CMD 0xA5
#define MAGIC_TEL 0xB5
#define WIFI_CH   1

enum : uint8_t { T_DRIVE = 1, T_PID, T_LIMIT, T_SAVE, T_AT, T_STOP, T_ZERO };
enum : uint8_t { FLG_FAILSAFE = 1, FLG_AT_RUN = 4, FLG_AT_DONE = 8 };
// at: 0 idle, 1 jalan, 2 selesai, 3 gagal

struct __attribute__((packed)) Hdr {
  uint8_t magic, type;
  uint8_t seq;      // nomor perintah (DRIVE: 0). Slave abaikan seq yang sama dengan yang terakhir.
  uint8_t target;   // 0 = semua roda, 1..3 = satu roda
};
struct __attribute__((packed)) PktDrive { Hdr h; float rpm[3]; };
struct __attribute__((packed)) PktPid   { Hdr h; float kp, ki, kd; };
struct __attribute__((packed)) PktLimit { Hdr h; float rpm; };
struct __attribute__((packed)) PktAt    { Hdr h; float sp; uint8_t rule; };  // rule 0=ZN 1=sedikit overshoot 2=tanpa overshoot
struct __attribute__((packed)) PktCmd   { Hdr h; };                          // SAVE, STOP, ZERO

struct __attribute__((packed)) PktTel {
  uint8_t magic, id, flags, at;
  float rpm, target;
  int16_t pwm;
  float kp, ki, kd, limit;
};
