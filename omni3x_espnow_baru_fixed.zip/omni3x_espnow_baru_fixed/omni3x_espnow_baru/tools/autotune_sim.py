#!/usr/bin/env python3
"""Uji logika Auto Tuning relay + PID slave tanpa hardware (replika src/slave/main.cpp).
Motor = orde-1 + deadband + kuantisasi encoder x1. Jalankan: python3 autotune_sim.py [--sp 30] [--rule 2]"""
import argparse, math, random

CPR, DT = 3860.0, 0.02
GAIN, TAU, DEAD = 0.45, 0.12, 25      # rpm per PWM, detik, deadband PWM (tebakan)

class Motor:
    def __init__(s): s.rpm = 0.0; s.cnt = 0.0; s.last = 0
    def step(s, pwm):
        eff = 0 if abs(pwm) < DEAD else math.copysign(abs(pwm) - DEAD, pwm)
        s.rpm += (GAIN * eff - s.rpm) * DT / TAU
        s.cnt += s.rpm / 60 * CPR * DT
        n = int(s.cnt); d = n - s.last; s.last = n
        return d

def run(sp, rule, limit=100.0):
    m = Motor(); filt = 0.0
    st, t0, pwm = "spin", 0.0, 0.0
    bias = d = 0; high = True; mx, mn = -1e9, 1e9; last_high = None; per = []; amp = []
    t = 0.0
    while t < 40:
        delta = m.step(int(pwm))
        filt = 0.7 * filt + 0.3 * (delta / CPR) * (60 / DT)
        if st == "spin":
            pwm += 1
            if filt >= sp:
                bias = pwm; d = min(bias * 0.4, 255 - bias)
                if d < 8: return None
                d = max(d, min(15, 255 - bias)); st = "relay"; high = True; mx, mn = -1e9, 1e9; last_high = None
            elif pwm >= 255: return None
        else:
            hyst = max(2.5, 0.06 * sp); mx = max(mx, filt); mn = min(mn, filt)
            if high and filt > sp + hyst: high = False
            elif (not high) and filt < sp - hyst:
                high = True
                if last_high is not None:
                    per.append(t - last_high); amp.append((mx - mn) / 2)
                last_high = t; mx, mn = -1e9, 1e9
                if len(per) >= 6:
                    Tu = sum(per[2:6]) / 4; a = sum(amp[2:6]) / 4
                    Ku = 4 * d / (math.pi * a)
                    kp, ti, td = {0: (.6 * Ku, .5 * Tu, .125 * Tu), 1: (.33 * Ku, .5 * Tu, .33 * Tu), 2: (.2 * Ku, .5 * Tu, .33 * Tu)}[rule]
                    return dict(kp=kp, ki=kp / ti, kd=kp * td, Tu=Tu, a=a, Ku=Ku, bias=bias, d=d, t=t)
            pwm = bias + (d if high else -d)
        t += DT
    return None

def closed_loop(kp, ki, kd, target=60.0, secs=4.0):
    m = Motor(); filt = 0; integ = 0; prev = 0; ramp = 0; out_log = []
    for k in range(int(secs / DT)):
        ramp = min(ramp + 300 * DT, target)
        delta = m.step(int(pwm_cl)) if k else 0
        filt = 0.7 * filt + 0.3 * (delta / CPR) * (60 / DT)
        err = ramp - filt; integ += err * DT
        il = 255 / ki if ki > 0 else 0; integ = max(-il, min(il, integ))
        dm = (filt - prev) / DT; prev = filt
        globals()['pwm_cl'] = max(-255, min(255, kp * err + ki * integ - kd * dm))
        out_log.append(m.rpm)
    return out_log

pwm_cl = 0.0
if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--sp", type=float, default=30); ap.add_argument("--rule", type=int, default=2)
    a = ap.parse_args()
    r = run(a.sp, a.rule)
    if not r: raise SystemExit("autotune GAGAL")
    print({k: round(v, 4) for k, v in r.items()})
    for tgt in (60.0,):
        pwm_cl = 0.0
        log = closed_loop(r["kp"], r["ki"], r["kd"], tgt)
        peak = max(log); fin = sum(log[-25:]) / 25
        print(f"step ke {tgt:.0f} rpm: puncak {peak:.1f} (overshoot {100*(peak-tgt)/tgt:.1f}%), akhir {fin:.1f}")
